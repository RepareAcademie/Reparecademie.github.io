# LibreSoudure

Plateforme **100 % gratuite** et ouverte pour apprendre les bases de la micro-soudure et de la réparation électronique.

## Fonctionnalités

- 12 leçons originales organisées en 4 modules
- Progression sauvegardée localement (localStorage)
- Quiz de validation (10 questions)
- Certificat téléchargeable (PNG généré dans le navigateur)
- Interface mobile-first moderne
- Aucune inscription, aucun serveur, aucune donnée envoyée

## Comment l’utiliser

### En local
Ouvre simplement le fichier `index.html` dans ton navigateur.

### Héberger gratuitement sur GitHub Pages
1. Crée un nouveau dépôt GitHub (ex: `libresoudure`)
2. Upload le fichier `index.html` (et ce README si tu veux)
3. Va dans **Settings → Pages**
4. Source : Deploy from a branch → `main` / root
5. Ton site sera disponible sur `https://ton-pseudo.github.io/libresoudure/`

Tu peux aussi le mettre dans un dossier `docs/` ou utiliser n’importe quel hébergeur statique (Netlify, Cloudflare Pages, Vercel, etc.).

## Personnalisation

Tout le contenu (leçons, quiz, modules) se trouve dans le fichier `index.html` dans les constantes JavaScript `MODULES` et `QUIZ`.  
Tu peux facilement ajouter des leçons, modifier les textes ou changer les couleurs.

## Licence

Ce projet est libre. Tu peux le modifier, le redistribuer et l’améliorer comme tu veux.
